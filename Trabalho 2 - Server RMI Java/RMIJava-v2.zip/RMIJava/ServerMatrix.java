/*
 * O servidor deve oferecer:
 * - Operações com matriz (implementando a interface IMatrix);
  */

public class ServerMatrix {
    
}
